package com.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductConsumerAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductConsumerAppApplication.class, args);
		System.out.println("App Running..");
	}

}
