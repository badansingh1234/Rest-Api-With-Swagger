package com.springboot;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer.Alphanumeric;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

@SpringBootTest
@AutoConfigureMockMvc
@DisplayName("PRODUCT APPLICATION")
@TestMethodOrder(Alphanumeric.class)
class ProductManagmentMiniProjectApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@Test
	@DisplayName("ALL PRODUCTS")
//	@Disabled
	@Tag("DEV")
	public void testGetAllProducts() throws Exception {
		// creating objects
		MockHttpServletRequestBuilder request = MockMvcRequestBuilders.get("/app/product/all");

		// execute request
		MvcResult result = mockMvc.perform(request).andReturn();

		// get response/result
		MockHttpServletResponse response = result.getResponse();

		// Assert Result
		assertEquals(HttpStatus.OK.value(), response.getStatus());

		assertNotNull(response.getContentAsString());
	}

	@Test
	@DisplayName("SINGLE PROJECT")
//	@Disabled
	@Tag("QA")
	public void testGetOneProduct() throws Exception {
		// creating objects
		MockHttpServletRequestBuilder request = MockMvcRequestBuilders.get("/app/product/find/1");

		// execute request
		MvcResult result = mockMvc.perform(request).andReturn();

		// get response/result
		MockHttpServletResponse response = result.getResponse();

		// Assert Result
		assertEquals(HttpStatus.OK.value(), response.getStatus());

		assertNotNull(response.getContentAsString());
	}

	@Test
//	@Disabled
	public void testsaveProduct() throws Exception {
		// creating objects
		MockHttpServletRequestBuilder request = MockMvcRequestBuilders.post("/app/product/save")
				.contentType(MediaType.APPLICATION_JSON)
				.content("{ \"proCode\": \"Oppo\",\n" + "  \"prodCost\": 6700,\n"
						+ "  \"prodVendor\": \"Oppo Pvt Ltd.\",\n" + "  \"prodGst\": 1206,\n" + "  \"prodDis\": 804}");

		// execute request
		MvcResult result = mockMvc.perform(request).andReturn();

		// get response/result
		MockHttpServletResponse response = result.getResponse();

		// Assert Result
		assertEquals(HttpStatus.CREATED.value(), response.getStatus());

		assertNotNull(response.getContentAsString());
	}

	@Test
//	@Disabled
	public void testdeleteById() throws Exception {
		// creating objects
		MockHttpServletRequestBuilder request = MockMvcRequestBuilders.delete("/app/product/remove/3");

		// execute request
		MvcResult result = mockMvc.perform(request).andReturn();

		// get response/result
		MockHttpServletResponse response = result.getResponse();

		// Assert Result
		assertEquals(HttpStatus.OK.value(), response.getStatus());

		assertNotNull(response.getContentAsString());
	}

}
