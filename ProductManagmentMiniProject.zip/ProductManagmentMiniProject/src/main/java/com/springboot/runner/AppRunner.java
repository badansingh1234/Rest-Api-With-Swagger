package com.springboot.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.springboot.repository.ProductRepo;
import com.springboot.service.ProductService;

@Component
public class AppRunner  implements CommandLineRunner{

	@Autowired
	private ProductService productService;
	
	@Autowired
	private ProductRepo productRepo;
	
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
//		System.out.println(productService.getClass().getName());
		
//		System.out.println(productRepo.getClass().getName());
		
	}

}
