package com.springboot.util;

import com.springboot.models.Product;

public interface CalculationUtil {

	public static void blogic(Product product) {
		Double cost = product.getProdCost();
		product.setProdDis(cost * 12 / 100);
		product.setProdGst(cost * 18 / 100);
	}
}
