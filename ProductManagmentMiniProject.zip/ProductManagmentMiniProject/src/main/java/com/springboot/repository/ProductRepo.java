package com.springboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.springboot.models.Product;

public interface ProductRepo  extends JpaRepository<Product, Integer>{

	@Modifying
	@Query("UPDATE Product p SET p.proCode=:code WHERE prodId=:id")
	public void updateCodeById(Integer id, String code);
}
