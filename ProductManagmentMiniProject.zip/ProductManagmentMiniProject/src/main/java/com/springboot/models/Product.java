package com.springboot.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Product {
	
	@Id
	@GeneratedValue
	@Column(name = "p_id")
	private Integer prodId;
	
	@Column(name = "p_code")
	private String proCode;
	
	@Column(name = "p_cost")
	private Double prodCost;
	
	@Column(name = "p_vend")
	private String prodVendor;
	
	@Column(name = "p_gst")
	private Double prodGst;
	
	@Column(name = "p_dis")
	private Double prodDis;

	public Integer getProdId() {
		return prodId;
	}

	public void setProdId(Integer prodId) {
		this.prodId = prodId;
	}

	public String getProCode() {
		return proCode;
	}

	public void setProCode(String proCode) {
		this.proCode = proCode;
	}

	public Double getProdCost() {
		return prodCost;
	}

	public void setProdCost(Double prodCost) {
		this.prodCost = prodCost;
	}

	public String getProdVendor() {
		return prodVendor;
	}

	public void setProdVendor(String prodVendor) {
		this.prodVendor = prodVendor;
	}

	public Double getProdGst() {
		return prodGst;
	}

	public void setProdGst(Double prodGst) {
		this.prodGst = prodGst;
	}

	public Double getProdDis() {
		return prodDis;
	}

	public void setProdDis(Double prodDis) {
		this.prodDis = prodDis;
	}

	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Product(Integer prodId, String proCode, Double prodCost, String prodVendor, Double prodGst, Double prodDis) {
		super();
		this.prodId = prodId;
		this.proCode = proCode;
		this.prodCost = prodCost;
		this.prodVendor = prodVendor;
		this.prodGst = prodGst;
		this.prodDis = prodDis;
	}

	@Override
	public String toString() {
		return "Product [prodId=" + prodId + ", proCode=" + proCode + ", prodCost=" + prodCost + ", prodVendor="
				+ prodVendor + ", prodGst=" + prodGst + ", prodDis=" + prodDis + "]";
	} 
	
	
	

}
