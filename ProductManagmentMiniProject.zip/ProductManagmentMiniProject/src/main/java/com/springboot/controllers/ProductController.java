package com.springboot.controllers;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.exception.ProductNotFoundException;
import com.springboot.models.Product;
import com.springboot.service.ProductService;

import io.swagger.annotations.Api;

@RestController
@RequestMapping("/app/product")
@Api(description = "Product APIs")
public class ProductController {
	
	private static final Logger LOG = LoggerFactory.getLogger(ProductController.class);

	@Autowired
	private ProductService productService;

	@PostMapping("/save")
	public ResponseEntity<String> saveProduct(@RequestBody Product product) {
		Integer id = productService.saveProduct(product);
		String data = "Product Data Save:  " + id;
		ResponseEntity<String> response = new ResponseEntity<String>(data, HttpStatus.CREATED);
		return response;
	}

	@GetMapping(value = "/all")
	public ResponseEntity<List<Product>> getAllProduct() {
		List<Product> list = productService.getAllProducts();
		ResponseEntity<List<Product>> response = new ResponseEntity<List<Product>>(list, HttpStatus.OK);
		return response;
	}

	@GetMapping(value = "/find/{id}")
	public ResponseEntity<?> getOneProduct(@PathVariable Integer id) {
		LOG.info("ENTERED IN GET ONE PRODUCT");
		
		ResponseEntity<?> response = null;
		try {
			Product product = productService.getOneProduct(id);
			response = new ResponseEntity<Product>(product, HttpStatus.OK);
		} catch (ProductNotFoundException pe) {
			pe.printStackTrace();
			response = new ResponseEntity<String>(pe.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	@DeleteMapping(value = "/remove/{id}")
	public ResponseEntity<String> deleteById(@PathVariable Integer id) {
		ResponseEntity<String> response = null;
		try {
			productService.deleteProduct(id);
			response = new ResponseEntity<String>("Product Removed Id " + id, HttpStatus.OK);
		} catch (ProductNotFoundException pe) {
			pe.printStackTrace();
			response = new ResponseEntity<String>(pe.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return response;
	}

	@RequestMapping(value = "/modify", method = RequestMethod.PUT)
	public ResponseEntity<?> updateProduct(@RequestBody Product product) {
		ResponseEntity<?> resp = null;

		try {
			productService.updateProduct(product);
			resp = new ResponseEntity<String>("Product updated " + product.getProdId(), HttpStatus.OK);
		} catch (ProductNotFoundException pe) {
			pe.printStackTrace();
			resp = new ResponseEntity<String>("Product not update " + product.getProdId(), HttpStatus.OK);
		}
		return resp;
	}

	@PatchMapping("/update/{id}/{code}")
	public ResponseEntity<String> updateCode(@PathVariable Integer id, @PathVariable String code) {
//		System.out.println("Enter patch...");
		ResponseEntity<String> response=null;
		try {
			productService.updateProductCodeById(id, code);
			response=new ResponseEntity<String>("Product Code is updated -"+id+"..."+code, HttpStatus.OK);
		} catch (ProductNotFoundException pe) {
			pe.printStackTrace();
			response=new ResponseEntity<String>(pe.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

}
