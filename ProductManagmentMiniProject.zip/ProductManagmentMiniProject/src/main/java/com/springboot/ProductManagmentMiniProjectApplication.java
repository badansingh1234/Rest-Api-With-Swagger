package com.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductManagmentMiniProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductManagmentMiniProjectApplication.class, args);
		
		System.out.println("App running...");
		
	}

}
