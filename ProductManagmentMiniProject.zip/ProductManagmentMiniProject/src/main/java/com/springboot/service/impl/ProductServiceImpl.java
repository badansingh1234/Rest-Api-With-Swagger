package com.springboot.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.expression.spel.ast.OpAnd;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.springboot.exception.ProductNotFoundException;
import com.springboot.models.Product;
import com.springboot.repository.ProductRepo;
import com.springboot.service.ProductService;
import com.springboot.util.CalculationUtil;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductRepo productRepo;

	@Override
	public Integer saveProduct(Product product) {
		CalculationUtil.blogic(product);
		productRepo.save(product);
		return product.getProdId();
	}

	@Override
	public void updateProduct(Product product) {
		CalculationUtil.blogic(product);
		productRepo.save(product);

	}

	@Override
	public void deleteProduct(Integer id) {
		Optional<Product> opt = productRepo.findById(id);
		if (opt.isPresent()) {
			productRepo.deleteById(id);

		} else {
			throw new ProductNotFoundException("Product Id " + id + "- Not Exist");
		}
	}

	@Override
	public Product getOneProduct(Integer id) {
		Optional<Product> opt = productRepo.findById(id);

		if (opt.isPresent()) {
			return opt.get();
		} else {
			throw new ProductNotFoundException("Product Id " + id + "- Not Exist");
		}
	}

	@Override
	public List<Product> getAllProducts() {
		return productRepo.findAll();
	}

	@Transactional
	public void updateProductCodeById(Integer id, String code) {
		if (!productRepo.existsById(id))
			throw new ProductNotFoundException("Product Id " + id + " - Not Found");

		productRepo.updateCodeById(id, code);

	}

}
