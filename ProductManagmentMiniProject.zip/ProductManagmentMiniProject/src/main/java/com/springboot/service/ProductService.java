package com.springboot.service;

import java.util.List;

import com.springboot.models.Product;

public interface ProductService {

	Integer saveProduct(Product product);

	Product updateProduct(Product product);

	void deleteProduct(Integer id);

	Product getOneProduct(Integer id);
	
	List<Product> getAllProducts();
	
	void updateProductCodeById(Integer id,String code);

}
