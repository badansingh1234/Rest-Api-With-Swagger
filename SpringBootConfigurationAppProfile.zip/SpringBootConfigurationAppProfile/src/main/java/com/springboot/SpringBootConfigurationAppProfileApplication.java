package com.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootConfigurationAppProfileApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootConfigurationAppProfileApplication.class, args);
		
		System.out.println("Application Running..");
	}

}
