package com.springboot.runner;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "my.app")
public class AppRunner implements CommandLineRunner {

	private String db;

	private String driver;

	public String getDb() {
		return db;
	}

	public void setDb(String db) {
		this.db = db;
	}

	public String getDriver() {
		return driver;
	}

	public void setDriver(String driver) {
		this.driver = driver;
	}

	public AppRunner(String db, String driver) {
		super();
		this.db = db;
		this.driver = driver;
	}
	
	

	public AppRunner() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "AppRunner [db=" + db + ", driver=" + driver + "]";
	}
	

	@Override
	public void run(String... args) throws Exception {
		
		System.out.println(this);
		
	}

}
